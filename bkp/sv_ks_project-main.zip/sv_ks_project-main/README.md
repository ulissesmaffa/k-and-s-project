## Knob and Switch Simulador em VHDL

Este é um repositório mantido como o projeto inicial para configurar o Xilinx Vivado para o desenvolvimento
do projeto do simulador do K&S em VHDL.

Aqui estão todos os arquivos necessários para a simulação e validação dos projetos desenvolvidos pelos alunos
do curso de Engenharia de Computação da Uergs em Guaíba.

